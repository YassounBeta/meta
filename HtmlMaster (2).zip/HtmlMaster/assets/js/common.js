/**
 * Common JavaScript functionality for Afrilavage
 * Contains shared functions used across multiple pages
 */

// Toast notification system
const toastContainer = document.createElement('div');
toastContainer.className = 'toast-container';
document.body.appendChild(toastContainer);

/**
 * Show a toast notification
 * @param {string} message - The message to display
 * @param {string} type - The type of toast: 'success', 'error', or 'info'
 * @param {number} duration - How long to show the toast in milliseconds
 */
function showToast(message, type = 'success', duration = 3000) {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    
    let iconClass = 'fas fa-check-circle';
    if (type === 'error') {
        iconClass = 'fas fa-exclamation-circle';
    } else if (type === 'info') {
        iconClass = 'fas fa-info-circle';
    }
    
    toast.innerHTML = `
        <div class="toast-icon">
            <i class="${iconClass}"></i>
        </div>
        <div class="toast-content">
            <p class="toast-message">${message}</p>
        </div>
        <button class="toast-close">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    // Close button event
    toast.querySelector('.toast-close').addEventListener('click', () => {
        toast.style.animation = 'slideOut 0.3s forwards';
        setTimeout(() => {
            toastContainer.removeChild(toast);
        }, 300);
    });
    
    toastContainer.appendChild(toast);
    
    // Auto-close after duration
    setTimeout(() => {
        if (toast.parentNode === toastContainer) {
            toast.style.animation = 'slideOut 0.3s forwards';
            setTimeout(() => {
                if (toast.parentNode === toastContainer) {
                    toastContainer.removeChild(toast);
                }
            }, 300);
        }
    }, duration);
}

/**
 * Update the navigation based on user login status
 * @param {string|null} currentUserStr - JSON string of current user, or null if not logged in
 */
function updateNavigation(currentUserStr) {
    const loginNavItem = document.getElementById('loginNavItem');
    const accountNavItem = document.getElementById('accountNavItem');
    const historyNavItem = document.getElementById('historyNavItem');
    const logoutNavItem = document.getElementById('logoutNavItem');
    
    if (currentUserStr) {
        // User is logged in
        if (loginNavItem) loginNavItem.style.display = 'none';
        if (accountNavItem) accountNavItem.style.display = 'block';
        if (historyNavItem) historyNavItem.style.display = 'block';
        if (logoutNavItem) logoutNavItem.style.display = 'block';
    } else {
        // User is not logged in
        if (loginNavItem) loginNavItem.style.display = 'block';
        if (accountNavItem) accountNavItem.style.display = 'none';
        if (historyNavItem) historyNavItem.style.display = 'none';
        if (logoutNavItem) logoutNavItem.style.display = 'none';
    }
}

/**
 * Generate a random order status for demo purposes
 * Returns one of the following statuses:
 * - En cours de traitement
 * - Lavage en cours
 * - En livraison
 * - Livré
 * 
 * @param {Date} orderDate - The date the order was placed
 * @returns {string} The order status
 */
function generateRandomStatus(orderDate) {
    const now = new Date();
    const hoursSinceOrder = (now - orderDate) / (1000 * 60 * 60);
    
    if (hoursSinceOrder < 2) {
        return 'En cours de traitement';
    } else if (hoursSinceOrder < 6) {
        return 'Lavage en cours';
    } else if (hoursSinceOrder < 10) {
        return 'En livraison';
    } else {
        return 'Livré';
    }
}

/**
 * Format a date as a string
 * @param {Date} date - The date to format
 * @returns {string} Formatted date string
 */
function formatDate(date) {
    if (!(date instanceof Date)) {
        date = new Date(date);
    }
    
    return date.toLocaleDateString('fr-FR', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
    });
}

/**
 * Add demo data for testing if none exists
 * This function adds sample users and orders if localStorage is empty
 */
function initializeDemoData() {
    // Check if users exist
    let users = JSON.parse(localStorage.getItem('users')) || [];
    if (users.length === 0) {
        // Add demo users
        users = [
            {
                id: 1001,
                name: 'Ahmed Benani',
                email: 'ahmed@example.com',
                phone: '0612345678',
                password: 'password123',
                isAdmin: false
            },
            {
                id: 1002,
                name: 'Fatima Zahra',
                email: 'fatima@example.com',
                phone: '0687654321',
                password: 'password123',
                isAdmin: false
            },
            {
                id: 9999,
                name: 'Administrateur',
                email: 'admin@afrilavage.com',
                phone: '0600000000',
                password: 'admin123',
                isAdmin: true
            }
        ];
        
        localStorage.setItem('users', JSON.stringify(users));
    }
    
    // Check if orders exist
    let orders = JSON.parse(localStorage.getItem('orders')) || [];
    if (orders.length === 0) {
        // Current date
        const now = new Date();
        
        // Add demo orders
        orders = [
            {
                id: 10001,
                userId: 1001,
                userName: 'Ahmed Benani',
                serviceType: 'pressing',
                serviceSpeed: 'express',
                address: '123 Avenue Mohammed V',
                city: 'Casablanca',
                phone: '0612345678',
                collectionDate: new Date(now.getTime() - 2 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
                collectionTime: '10:00',
                instructions: 'Sonnez à l\'interphone 203',
                date: new Date(now.getTime() - 2 * 24 * 60 * 60 * 1000).toISOString(),
                status: 'Livré',
                paymentMethod: 'Paiement à la livraison',
                price: 80
            },
            {
                id: 10002,
                userId: 1001,
                userName: 'Ahmed Benani',
                serviceType: 'car',
                serviceSpeed: 'standard',
                address: '123 Avenue Mohammed V',
                city: 'Casablanca',
                phone: '0612345678',
                collectionDate: new Date(now.getTime() - 1 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
                collectionTime: '14:00',
                instructions: '',
                date: new Date(now.getTime() - 1 * 24 * 60 * 60 * 1000).toISOString(),
                status: 'En livraison',
                paymentMethod: 'Paiement à la livraison',
                price: 100
            },
            {
                id: 10003,
                userId: 1002,
                userName: 'Fatima Zahra',
                serviceType: 'pressing',
                serviceSpeed: 'standard',
                address: '45 Rue Ibn Batouta',
                city: 'Rabat',
                phone: '0687654321',
                collectionDate: new Date(now.getTime() - 12 * 60 * 60 * 1000).toISOString().split('T')[0],
                collectionTime: '16:00',
                instructions: 'Traitement délicat pour les soies',
                date: new Date(now.getTime() - 12 * 60 * 60 * 1000).toISOString(),
                status: 'Lavage en cours',
                paymentMethod: 'Paiement à la livraison',
                price: 50
            },
            {
                id: 10004,
                userId: 1002,
                userName: 'Fatima Zahra',
                serviceType: 'car',
                serviceSpeed: 'express',
                address: '45 Rue Ibn Batouta',
                city: 'Rabat',
                phone: '0687654321',
                collectionDate: new Date(now.getTime() - 3 * 60 * 60 * 1000).toISOString().split('T')[0],
                collectionTime: '09:00',
                instructions: '',
                date: new Date(now.getTime() - 3 * 60 * 60 * 1000).toISOString(),
                status: 'En cours de traitement',
                paymentMethod: 'Paiement à la livraison',
                price: 130
            }
        ];
        
        localStorage.setItem('orders', JSON.stringify(orders));
    }
}

// Initialize demo data on page load
document.addEventListener('DOMContentLoaded', function() {
    initializeDemoData();
});
